import requests
import re
import os


user = input("Enter the image name: ")

user_agent = {
    "User-Agent" : "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36"
}
url = f"https://www.google.com/search?sca_esv=a5f19cfa0813df82&rlz=1C1ONGR_enIN1165IN1165&q={user}&udm=2&fbs=AIIjpHxU7SXXniUZfeShr2fp4giZ1Y6MJ25_tmWITc7uy4KIeqDdErwP5rACeJAty2zADJjYuUnSkczEhozYdaq1wZrEheAY38UjnRKVLYFDREDmz6ZuF5vGKadO4eyTxfJeUAUMG824jBAJyyOFku2EE6yFAMG92rVlgj_vAxQXNB1YTKi5vnFC7sIzwBMMxojLsnnE1TcdECqxzRobFhi6gbOmGGyvyA&sa=X&ved=2ahUKEwjQ5qOu-OSNAxWge_UHHWfzEKkQtKgLegQIExAB&biw=725&bih=585&dpr=1.5"

response = requests.get(url=url , headers=user_agent).content

pattern = r"\[\"https://.*\.jpg\",[0-9]+,[0-9]+\]"

response = response.decode('utf-8')
images = re.findall(pattern , response)
for image in images:
    print(image)

#https://d3i6fh83elv35t.cloudfront.net/static/2023/08/GettyImages-1634839624-1024x691.jpg",691,1024]