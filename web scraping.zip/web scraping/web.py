import requests

url = "http://127.0.0.1:8000/helloworld/"

user = {
    "User_Agent" : "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36"
}

response = requests.get(url = url , headers=user)
print(response.content)