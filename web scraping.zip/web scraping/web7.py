import requests
from bs4 import BeautifulSoup

class PriceTracer:
    def __init__(self , url):
        self.url = url
        self.user_agent = {"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36"}
        self.response = requests.get(url=self.url,headers=self.user_agent).text
        self.soup = BeautifulSoup(self.response, "lxml")

    def product_title(self):
        title = self.soup.find("span", {"id": "productTitle"})
        if title is not None:
            return title.text
        else:
            return "Tag not found"


    def product_price(self):
        price = self.soup.find("span", {"class": "a-price-whole"})
        if price is not None:
            return price.text
        else:
            return "Tag not found"


#device = PriceTracer(url="https://www.amazon.in/LG-Inverter-Direct-Cool-Refrigerator-GL-D201ABEU/dp/B0041XZS54/ref=sr_1_16?_encoding=UTF8&content-id=amzn1.sym.58c90a12-100b-4a2f-8e15-7c06f1abe2be&dib=eyJ2IjoiMSJ9.WeNO08BDbM9HwjBZfrKHXUMi1QQo22id3_xnDyYQ-fHio_CPbXIlNAg1aLSLiNKelbG2QpD0F-ON91Fk9biLOHDU37AtAERqIcTQQCogp5z66E7yrJsg1K5FpufqOGOKkuJBt_j0VSYlH82jlvGkosYjxy72HicgWU8AUaQc26_WYqOTnYSUX6QAOE39MZeH5tfGkaiUIpsZJzzcHrXv5XzxHoOYOHNfsOB4xOqNqHhteWmPsQIrotHUIR1C7KLY3WOdan_NwFP4FyeuJtNPCItGqMAwN4jJy3_DKf8gFOY.Coo_KM94SQmVgq_oMfW4ebZ68-kYVwkqPAzsTTKYIMs&dib_tag=se&pd_rd_r=ac1c7a6d-6773-4fc7-bd6a-9dadc9a4a273&pd_rd_w=t1r8w&pd_rd_wg=Tsyp9&qid=1749522127&refinements=p_85%3A10440599031&rps=1&s=kitchen&sr=1-16&th=1")
#print(device.product_title())
#print(device.product_price())

washingm = PriceTracer(url="https://www.amazon.in/dp/B0D53LM2CX/ref=sspa_dk_detail_4?pd_rd_i=B0D53LM2CX&pd_rd_w=apIeV&content-id=amzn1.sym.9f1cb690-f0b7-44de-b6ff-1bad1e37d3f0&pf_rd_p=9f1cb690-f0b7-44de-b6ff-1bad1e37d3f0&pf_rd_r=4JNYGG29SN21H7YXA44E&pd_rd_wg=pEfsw&pd_rd_r=2fb466dc-56fc-4685-bd27-eab61d5eb2ae&sp_csd=d2lkZ2V0TmFtZT1zcF9kZXRhaWxfdGhlbWF0aWM&th=1")
print(washingm.product_title())
print(washingm.product_price())

