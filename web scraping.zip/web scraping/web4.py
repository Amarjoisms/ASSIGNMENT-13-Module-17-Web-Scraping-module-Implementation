import requests
from sqlparse.utils import offset

url = "http://127.0.0.1:8000/post/"

param = {
    "offset" : "2"
}

response = requests.post(url = url , params=param)

print(response.url)
